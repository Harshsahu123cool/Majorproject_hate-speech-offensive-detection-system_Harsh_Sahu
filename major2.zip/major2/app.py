from flask import Flask, render_template, request, send_file
import joblib
import re
import nltk
from nltk.corpus import stopwords
import PyPDF2
import docx
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import os

app = Flask(__name__)

# Load model
model = joblib.load("model/model.pkl")
vectorizer = joblib.load("model/vectorizer.pkl")
encoder = joblib.load("model/encoder.pkl")

nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Preprocess
def preprocess(text):
    text = text.lower()
    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"[^a-zA-Z]", " ", text)
    words = text.split()
    words = [word for word in words if word not in stop_words]
    return " ".join(words)

# FILE READERS
def extract_pdf(file):
    reader = PyPDF2.PdfReader(file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text

def extract_docx(file):
    doc = docx.Document(file)
    return "\n".join([p.text for p in doc.paragraphs])

def extract_txt(file):
    return file.read().decode("utf-8")

# Prediction
def predict_lines(text):
    lines = re.split(r'[.!?\n]', text)
    results = []

    for line in lines:
        if line.strip() == "":
            continue

        clean = preprocess(line)
        vector = vectorizer.transform([clean])

        pred = model.predict(vector)[0]
        label = encoder.inverse_transform([pred])[0]
        prob = model.predict_proba(vector).max()

        results.append({
            "text": line,
            "label": label,
            "confidence": round(prob * 100, 2)
        })

    return results

# Dashboard stats
def get_stats(results):
    stats = {"hate_speech": 0, "offensive": 0, "neither": 0}

    for r in results:
        stats[r["label"]] += 1

    return stats

# PDF Report
def generate_pdf(results):
    file_path = "report.pdf"
    doc = SimpleDocTemplate(file_path)
    styles = getSampleStyleSheet()

    content = []

    for r in results:
        text = f"{r['text']} → {r['label']} ({r['confidence']}%)"
        content.append(Paragraph(text, styles["Normal"]))

    doc.build(content)
    return file_path

# ROUTE
@app.route("/", methods=["GET", "POST"])
def home():
    results = None
    stats = None
    text_input = ""

    if request.method == "POST":

        # TEXT INPUT
        if request.form.get("text"):
            text_input = request.form["text"]

        # FILE INPUT
        file = request.files.get("file")

        if file and file.filename != "":
            if file.filename.endswith(".pdf"):
                text_input = extract_pdf(file)
            elif file.filename.endswith(".docx"):
                text_input = extract_docx(file)
            elif file.filename.endswith(".txt"):
                text_input = extract_txt(file)

        if text_input:
            results = predict_lines(text_input)
            stats = get_stats(results)

            # Download report
            if "download" in request.form:
                path = generate_pdf(results)
                return send_file(path, as_attachment=True)

    return render_template("index.html", results=results, stats=stats, text_input=text_input)


if __name__ == "__main__":
    app.run(debug=True)