import pandas as pd
import re
import nltk
import joblib
import os

from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report

# Download stopwords
nltk.download('stopwords')

# Load dataset
df = pd.read_csv(r"D:\\major2\\hate_speech_dataset.csv")

print("Columns:", df.columns)
print(df.head())

# Setup
stop_words = set(stopwords.words('english'))

# Preprocess function
def preprocess(text):
    text = str(text).lower()
    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"[^a-zA-Z]", " ", text)
    words = text.split()
    words = [word for word in words if word not in stop_words]
    return " ".join(words)

# ✅ FIXED columns (IMPORTANT)
# Preprocess
df['clean_text'] = df['text'].apply(preprocess)

# Encode labels
encoder = LabelEncoder()
df['label_encoded'] = encoder.fit_transform(df['label'])

X = df['clean_text']
y = df['label_encoded']

# Vectorization
vectorizer = TfidfVectorizer(max_features=8000)
X = vectorizer.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Evaluation
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# Save model
os.makedirs("model", exist_ok=True)
joblib.dump(model, "model/model.pkl")
joblib.dump(vectorizer, "model/vectorizer.pkl")
joblib.dump(encoder, "model/encoder.pkl")

print("Model saved successfully ✅")